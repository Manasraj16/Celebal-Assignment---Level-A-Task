Use AdventureWorks2019
Go
SELECT * FROM Production.Product ORDER BY Name;