Use AdventureWorks2019
Go
SELECT * FROM Sales.Customer;
