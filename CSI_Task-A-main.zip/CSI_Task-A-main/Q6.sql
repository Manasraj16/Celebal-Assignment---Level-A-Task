Use AdventureWorks2019
Go
SELECT * FROM Production.Product WHERE Name LIKE 'A%';