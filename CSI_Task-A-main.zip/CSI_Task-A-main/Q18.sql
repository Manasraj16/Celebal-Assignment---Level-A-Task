Use AdventureWorks2019
Go
SELECT * FROM Sales.SalesOrderHeader WHERE ShipCountryRegion = 'Canada';