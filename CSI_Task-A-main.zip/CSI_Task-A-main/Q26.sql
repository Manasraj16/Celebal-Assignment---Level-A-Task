Use AdventureWorks2019
Go
SELECT * FROM HumanResources.Employee WHERE FirstName LIKE '%a%';