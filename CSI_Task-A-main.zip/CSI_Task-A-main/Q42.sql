Use AdventureWorks2019
Go
SELECT SUM(sod.LineTotal) AS TotalRevenue
FROM Sales.SalesOrderDetail sod;