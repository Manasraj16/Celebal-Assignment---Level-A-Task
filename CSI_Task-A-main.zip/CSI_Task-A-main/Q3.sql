Use AdventureWorks2019
Go
SELECT * FROM Sales.Customer 
WHERE City = 'Berlin' OR City = 'London';
