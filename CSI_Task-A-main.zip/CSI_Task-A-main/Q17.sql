Use AdventureWorks2019
Go
SELECT * FROM Sales.SalesOrderHeader WHERE OrderDate >= '1996-12-31';